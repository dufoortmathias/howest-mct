[connector_python]
user = root
host = 127.0.0.1
port = 3306
password = root
database = trein

[application_config]
driver = 'SQL Server'
